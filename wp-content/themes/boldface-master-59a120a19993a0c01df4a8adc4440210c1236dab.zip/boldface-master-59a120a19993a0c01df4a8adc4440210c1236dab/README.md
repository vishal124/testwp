# Boldface

## Requirements

- WordPress 4.8 or greater
- PHP 7.0 or greater

## Installation

1. [Download](https://gitlab.com/boldface/boldface/repository/archive.zip) the project ZIP file
2. Extract the ZIP file in your wp-content/themes/ directory
3. Rename the extracted directory to 'boldface'
4. Navigate in your browser to your wp-admin/themes.php page and activate the theme

## Documentation
